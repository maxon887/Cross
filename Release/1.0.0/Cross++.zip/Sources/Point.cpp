/*	Copyright © 2015 Lukyanau Maksim

	This file is part of Cross++ Game Engine.

    Cross++ Game Engine is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Cross++ is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Cross++.  If not, see <http://www.gnu.org/licenses/>			*/
	
#include "Point.h"

using namespace cross;

Point::Point(){
	x = -100;
	y = -100;
}

Point::Point(float x, float y){
	this->x = x;
	this->y = y;
}

bool Point::operator == (const Point& p){
	if(this->x == p.x && this->y && p.y)
		return true;
	else
		return false;
}

bool Point::operator != (const Point& p){
	return !((*this) == p);
}