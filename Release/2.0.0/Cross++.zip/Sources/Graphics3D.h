#pragma once
#include "Cross.h"
#include "GraphicsGL.h"

namespace cross{

class Graphics3D : public GraphicsGL{
public:
private:
};

}
