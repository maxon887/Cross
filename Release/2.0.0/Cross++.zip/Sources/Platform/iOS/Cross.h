//
//  Cross.h
//  Cross++
//
//  Created by mouse on 6/22/15.
//  Copyright (c) 2015 Lukyanau Maksim. All rights reserved.
//

#pragma once

#include "Game.h"

cross::Game* CrossMain(cross::Launcher* launcher);